import requests


Data = open('./sample.pdf', 'rb').read()
headers = {'Content-type': 'application/pdf'}
url='https://tntebi6bybo.SANDBOX.verygoodproxy.com/redact'
r = requests.post(url,data=Data, headers=headers)


#with open('sample-redacted.pdf', 'wb') as f:
   # f.write(r.content)




